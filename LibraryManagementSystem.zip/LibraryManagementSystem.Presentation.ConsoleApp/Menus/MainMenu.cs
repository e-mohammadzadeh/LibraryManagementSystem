﻿using LibraryManagementSystem.Application.Services;
using LibraryManagementSystem.Presentation.ConsoleApp.Helpers;

namespace LibraryManagementSystem.Presentation.ConsoleApp.Menus;

public static class MainMenu
{
	public static void MainMenuController(AuthorManagementService authorManagementService,
		UserManagementService userManagementService, BookManagementService bookManagementService)
	{
		var continueProgram = true;
		while (continueProgram)
		{
			switch (MainMenuList())
			{
				case 1:
				{
					Console.Clear();
					AuthorMenu.AuthorMenuController(authorManagementService);
					break;
				}
				case 2:
				{
					Console.Clear();
					BookMenu.BookMenuController(authorManagementService, bookManagementService);
					break;
				}
				case 3:
				{
					Console.Clear();
					UserMenu.UserMenuController(userManagementService);
					break;
				}
				case 4:
				{
					Console.Clear();
					Console.WriteLine("Option 4 selected.");
					break;
				}
				case 5:
				{
					ConsoleHelper.ShowError("Exiting Program...\n");
					continueProgram = false;
					break;
				}
			}
		}
	}


	private static int MainMenuList()
	{
		while (true)
		{
			Console.WriteLine("============================ MAIN MENU ============================");
			Console.WriteLine("1. Authors");
			Console.WriteLine("2. Books");
			Console.WriteLine("3. Members");
			Console.WriteLine("4. Borrowing");
			Console.WriteLine("5. Exit");
			Console.WriteLine("==================================================================");
			Console.Write("Please Enter a number: ");

			var option = Console.ReadLine();
			if (int.TryParse(option, out var result) && result is >= 1 and <= 5)
			{
				return result;
			}

			ConsoleHelper.ShowError("Invalid selection, Try again.\n");
		}
	}
}